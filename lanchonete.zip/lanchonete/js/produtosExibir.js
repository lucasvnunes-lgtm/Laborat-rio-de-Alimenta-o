import { produtos } from "./proutos";
let divPrincipal = document.getElementsByClassName("col-lg-3 col-md-6");
produtos.forEach(element => {
    let boxitem = document.createElement("div");
    let boxImagem = document.createElement("div");
    let img = document.createElement("img");
    let boxInf = document.createElement("div");
    let nomeProduto = document.createElement("h2");
    let info = document.createElement("p");
    let boxvalor = document.createElement("div");
    let valor = document.createElement("a");

    valor.textContent = element.preco;
    nomeProduto.textContent = element.nome;
    img.src = element.url;
    info.textContent = element.infor;

    boxvalor.appendChild(valor)
    boxInf.appendChild(nomeProduto)
    boxInf.appendChild(info)
    boxImagem.appendChild(img)
    boxitem.appendChild(boxImagem)
});


// <div class="col-lg-3 col-md-6">
//                               <div class="coffee_img"><img src="images/img-4.png"></div>
//                               <div class="coffee_box">
//                                  <h3 class="types_text">COFFEE TO GO</h3>
//                                  <p class="looking_text">looking at its layout. The point of</p>
//                                  <div class="read_bt"><a href="#">Read More</a></div>
//                               </div>
//                            </div>