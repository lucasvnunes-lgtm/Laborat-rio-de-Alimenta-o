export let produtos = {
    cafe:{
        url: "abouny-img.png",
        info: "café e agua",
        nome:"Café",
        preco:39.99
    },
    cafeGrand:{
        url: "abouny-img.png",
        infor: "café e agua",
        nome:"Café Grande", 
        preco:100
    },

    
// Salgados
Coxinha: {
    img: "coxinha.png",
    nome: "Coxinha",
    preco: 6
},
Enroladinho_Salsicha: {
    img: "enroladinho-salsicha.png",
    nome: "Enroladinho de Salsicha",
    preco: 6
},
Pao_Recheado: {
    img: "pao-recheado.png",
    nome: "Pão Recheado/Folhado",
    preco: 7
},

// Doces e Chocolates
BIS_Xtra: {
    img: "bis-xtra.png",
    nome: "BIS Xtra",
    preco: 5
},
KitKat: {
    img: "kitkat.png",
    nome: "KitKat",
    preco: 6
},
Serenata_Amor: {
    img: "serenata-amor.png",
    nome: "Serenata de Amor",
    preco: 2.5
},
Pirulitos_Variados: {
    img: "pirulitos.png",
    nome: "Pirulitos Variados",
    preco: 1.5
},
Doce_Corte: {
    img: "doce-corte.png",
    nome: "Doce de Corte (Doce de Leite/Rapadura)",
    preco: 4
},
Bolo: {
    img: "bolo.png",
    nome: "Bolo",
    preco: 5
},

// Gelados
Sorvete_Paleta: {
    img: "paleta.png",
    nome: "Sorvete Paleta Laska Gourmet (Sabores Variados)",
    preco: 10
},

// Bebidas
Coca_Cola_Lata: {
    img: "coca-cola-lata.png",
    nome: "Coca-Cola Lata",
    preco: 6
},
Fanta_Laranja_Lata: {
    img: "fanta-laranja-lata.png",
    nome: "Fanta Laranja Lata",
    preco: 6
},
Fanta_Uva_Lata: {
    img: "fanta-uva-lata.png",
    nome: "Fanta Uva Lata",
    preco: 6
},
Pepsi_Lata: {
    img: "pepsi-lata.png",
    nome: "Pepsi Lata",
    preco: 6
},
Sprite_Garrafa: {
    img: "sprite-garrafa.png",
    nome: "Sprite Garrafa",
    preco: 7
},
Guaramix_Copo: {
    img: "guaramix-copo.png",
    nome: "Guaramix Copo",
    preco: 5
},
Agua_Garrafa: {
    img: "agua-garrafa.png",
    nome: "Garrafa D'Água",
    preco: 3
},
Agua_Davila: {
    img: "agua-davila.png",
    nome: "Água Mineral D’Avila",
    preco: 3
},
Guarana_Jesus: {
    img: "guarana-jesus.png",
    nome: "Guaraná Jesus Garrafa",
    preco: 7
},
Suco_Maguary: {
    img: "suco-maguary.png",
    nome: "Suco em Caixa Maguary",
    preco: 5
},
Suco_Caseiro: {
    img: "suco-caseiro.png",
    nome: "Suco Caseiro",
    preco: 6
},

// Salgadinhos
Amendupa_Queijo: {
    img: "amendupa-queijo.png",
    nome: "Amendupã Snacks Queijo",
    preco: 4
},
Amendupa_Calabresa: {
    img: "amendupa-calabresa.png",
    nome: "Amendupã Snacks Calabresa",
    preco: 4
},
SolHits_Requeijao: {
    img: "solhits-requeijao.png",
    nome: "Sol Hits Requeijão",
    preco: 3.5
},
SolHits_Queijo: {
    img: "solhits-queijo.png",
    nome: "Sol Hits Queijo",
    preco: 3.5
},
Club_Social: {
    img: "club-social.png",
    nome: "Club Social",
    preco: 3
}


}